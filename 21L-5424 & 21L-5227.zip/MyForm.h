#pragma once

namespace Projfin {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	
	/// Summary for MyForm
	
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button7;
	protected:
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ logo;


	private: System::Windows::Forms::Button^ btnNew;
	private: System::Windows::Forms::Button^ btnres;

	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::Label^ label7;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->logo = (gcnew System::Windows::Forms::Panel());
			this->btnNew = (gcnew System::Windows::Forms::Button());
			this->btnres = (gcnew System::Windows::Forms::Button());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->panel3->SuspendLayout();
			this->SuspendLayout();
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button7->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button7.BackgroundImage")));
			this->button7->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button7->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button7->ImageAlign = System::Drawing::ContentAlignment::BottomLeft;
			this->button7->Location = System::Drawing::Point(8, 219);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(108, 113);
			this->button7->TabIndex = 0;
			this->button7->Text = L" ";
			this->button7->UseVisualStyleBackColor = false;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button8->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button8.BackgroundImage")));
			this->button8->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button8->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button8->Location = System::Drawing::Point(111, 219);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(115, 113);
			this->button8->TabIndex = 1;
			this->button8->Text = L" ";
			this->button8->UseVisualStyleBackColor = false;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button9
			// 
			this->button9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button9->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button9.BackgroundImage")));
			this->button9->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button9->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button9->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->button9->Location = System::Drawing::Point(222, 219);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(111, 113);
			this->button9->TabIndex = 2;
			this->button9->Text = L" ";
			this->button9->UseVisualStyleBackColor = false;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.BackgroundImage")));
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button1->ImageAlign = System::Drawing::ContentAlignment::TopLeft;
			this->button1->Location = System::Drawing::Point(8, 7);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(108, 113);
			this->button1->TabIndex = 0;
			this->button1->Text = L" ";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button2.BackgroundImage")));
			this->button2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button2->Cursor = System::Windows::Forms::Cursors::Default;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button2->ImageAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->button2->Location = System::Drawing::Point(111, 7);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(115, 113);
			this->button2->TabIndex = 1;
			this->button2->Text = L" ";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button3->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button3.BackgroundImage")));
			this->button3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button3->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button3->Location = System::Drawing::Point(222, 7);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(111, 113);
			this->button3->TabIndex = 2;
			this->button3->Text = L" ";
			this->button3->TextImageRelation = System::Windows::Forms::TextImageRelation::TextAboveImage;
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button4->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button4.BackgroundImage")));
			this->button4->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button4->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button4->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->button4->Location = System::Drawing::Point(8, 117);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(108, 113);
			this->button4->TabIndex = 0;
			this->button4->Text = L" ";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button5->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button5.BackgroundImage")));
			this->button5->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button5->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button5->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->button5->Location = System::Drawing::Point(111, 117);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(115, 113);
			this->button5->TabIndex = 1;
			this->button5->Text = L" ";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button6->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button6.BackgroundImage")));
			this->button6->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button6->ForeColor = System::Drawing::Color::WhiteSmoke;
			this->button6->ImageAlign = System::Drawing::ContentAlignment::TopLeft;
			this->button6->Location = System::Drawing::Point(222, 117);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(111, 113);
			this->button6->TabIndex = 2;
			this->button6->Text = L" ";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::White;
			this->panel1->Controls->Add(this->button6);
			this->panel1->Controls->Add(this->button3);
			this->panel1->Controls->Add(this->button9);
			this->panel1->Controls->Add(this->button5);
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->button4);
			this->panel1->Controls->Add(this->button8);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Controls->Add(this->button7);
			this->panel1->ForeColor = System::Drawing::Color::Maroon;
			this->panel1->Location = System::Drawing::Point(12, 124);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(343, 341);
			this->panel1->TabIndex = 0;
			// 
			// logo
			// 
			this->logo->BackColor = System::Drawing::Color::Transparent;
			this->logo->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"logo.BackgroundImage")));
			this->logo->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->logo->Location = System::Drawing::Point(189, 1);
			this->logo->Name = L"logo";
			this->logo->Size = System::Drawing::Size(504, 73);
			this->logo->TabIndex = 1;
			// 
			// btnNew
			// 
			this->btnNew->BackColor = System::Drawing::Color::White;
			this->btnNew->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnNew.BackgroundImage")));
			this->btnNew->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->btnNew->Font = (gcnew System::Drawing::Font(L"Microsoft Tai Le", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnNew->ForeColor = System::Drawing::Color::White;
			this->btnNew->ImageAlign = System::Drawing::ContentAlignment::TopRight;
			this->btnNew->Location = System::Drawing::Point(688, 271);
			this->btnNew->Name = L"btnNew";
			this->btnNew->Size = System::Drawing::Size(128, 98);
			this->btnNew->TabIndex = 2;
			this->btnNew->Text = L"New Game";
			this->btnNew->UseVisualStyleBackColor = false;
			this->btnNew->Click += gcnew System::EventHandler(this, &MyForm::btnNew_Click);
			// 
			// btnres
			// 
			this->btnres->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"btnres.BackgroundImage")));
			this->btnres->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->btnres->Font = (gcnew System::Drawing::Font(L"Microsoft Tai Le", 20.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnres->ForeColor = System::Drawing::Color::White;
			this->btnres->Location = System::Drawing::Point(375, 271);
			this->btnres->Name = L"btnres";
			this->btnres->Size = System::Drawing::Size(135, 98);
			this->btnres->TabIndex = 2;
			this->btnres->Text = L"Restart Game";
			this->btnres->UseVisualStyleBackColor = true;
			this->btnres->Click += gcnew System::EventHandler(this, &MyForm::btnres_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::DimGray;
			this->panel2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel2.BackgroundImage")));
			this->panel2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel2->Controls->Add(this->label9);
			this->panel2->Controls->Add(this->label8);
			this->panel2->Controls->Add(this->label6);
			this->panel2->Controls->Add(this->label1);
			this->panel2->Controls->Add(this->label4);
			this->panel2->Controls->Add(this->label3);
			this->panel2->Controls->Add(this->label5);
			this->panel2->Controls->Add(this->label2);
			this->panel2->Location = System::Drawing::Point(361, 131);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(455, 139);
			this->panel2->TabIndex = 3;
			this->panel2->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel2_Paint);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::White;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::Color::Black;
			this->label9->Location = System::Drawing::Point(390, 96);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(29, 31);
			this->label9->TabIndex = 4;
			this->label9->Text = L"0";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::White;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::Black;
			this->label8->Location = System::Drawing::Point(390, 7);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(29, 31);
			this->label8->TabIndex = 4;
			this->label8->Text = L"0";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::White;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::Color::Black;
			this->label6->Location = System::Drawing::Point(279, 96);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(82, 31);
			this->label6->TabIndex = 3;
			this->label6->Text = L"Total ";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::White;
			this->label1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::Black;
			this->label1->Location = System::Drawing::Point(276, 7);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(94, 33);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Draws";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::White;
			this->label4->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::Black;
			this->label4->Location = System::Drawing::Point(173, 96);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(31, 33);
			this->label4->TabIndex = 1;
			this->label4->Text = L"0";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->label4->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::White;
			this->label3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::Black;
			this->label3->Location = System::Drawing::Point(173, 7);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(31, 33);
			this->label3->TabIndex = 1;
			this->label3->Text = L"0";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::White;
			this->label5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::Black;
			this->label5->Location = System::Drawing::Point(14, 96);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(121, 33);
			this->label5->TabIndex = 0;
			this->label5->Text = L"Player O";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::White;
			this->label2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::Black;
			this->label2->Location = System::Drawing::Point(17, 7);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(118, 33);
			this->label2->TabIndex = 0;
			this->label2->Text = L"Player X";
			// 
			// panel3
			// 
			this->panel3->Controls->Add(this->label7);
			this->panel3->Location = System::Drawing::Point(408, 77);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(367, 48);
			this->panel3->TabIndex = 4;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Ravie", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::White;
			this->label7->Location = System::Drawing::Point(34, 0);
			this->label7->Name = L"label7";
			this->label7->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
			this->label7->Size = System::Drawing::Size(278, 43);
			this->label7->TabIndex = 0;
			this->label7->Text = L"Score Board";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Black;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(886, 559);
			this->Controls->Add(this->panel3);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->btnres);
			this->Controls->Add(this->btnNew);
			this->Controls->Add(this->logo);
			this->Controls->Add(this->panel1);
			this->ForeColor = System::Drawing::Color::White;
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->panel1->ResumeLayout(false);
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->ResumeLayout(false);

		}
		Boolean	chck;
		int add, total;
		bool win = false;
#pragma endregion
	
		void Enable_f() {
			button1->Enabled = false;
			button2->Enabled = false;
			button3->Enabled = false;
			button4->Enabled = false;
			button5->Enabled = false;
			button6->Enabled = false;
			button7->Enabled = false;
			button8->Enabled = false;
			button9->Enabled = false;

		}
		void score_board() {
			
			
			//win//=============
			//row1
			 
			

			
				
			if (button1->Text != " " && button1->Text == button2->Text && button1->Text == button3->Text) {
				button1->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button2->BackColor = System::Drawing::Color::White;
				button3->BackColor = System::Drawing::Color::White;

				if (button1->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button1->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//col1
			if (button1->Text != " " && button1->Text == button4->Text && button1->Text == button7->Text) {
				button1->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button4->BackColor = System::Drawing::Color::White;
				button7->BackColor = System::Drawing::Color::White;

				if (button1->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button1->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//row2
			if (button4->Text != " " && button4->Text == button5->Text && button4->Text == button6->Text) {
				button4->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button5->BackColor = System::Drawing::Color::White;
				button6->BackColor = System::Drawing::Color::White;

				if (button4->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button4->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//col2
			if (button2->Text != " " && button2->Text == button5->Text && button2->Text == button8->Text) {
				button2->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button5->BackColor = System::Drawing::Color::White;
				button8->BackColor = System::Drawing::Color::White;

				if (button2->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button2->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//row3
			if (button7->Text != " " && button7->Text == button8->Text && button7->Text == button9->Text) {
				button7->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button8->BackColor = System::Drawing::Color::White;
				button9->BackColor = System::Drawing::Color::White;

				if (button7->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button7->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//col3
			if (button3->Text != " " && button3->Text == button6->Text && button3->Text == button9->Text) {
				button3->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button6->BackColor = System::Drawing::Color::White;
				button9->BackColor = System::Drawing::Color::White;

				if (button3->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button3->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//diag1
			if (button1->Text != " " && button1->Text == button5->Text && button1->Text == button9->Text) {
				button1->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button5->BackColor = System::Drawing::Color::White;
				button9->BackColor = System::Drawing::Color::White;

				if (button1->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button1->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//diag2
			if (button3->Text != " " && button3->Text == button5->Text && button3->Text == button7->Text) {
				button3->BackColor = System::Drawing::Color::White;
				/*button1->BackColor=System::Drawing::ContentAlignment::TopCenter;*/
				button5->BackColor = System::Drawing::Color::White;
				button7->BackColor = System::Drawing::Color::White;

				if (button3->Text == "X") {
					win = true;
					MessageBox::Show(" Player X has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label3->Text);
					label3->Text = Convert::ToString(add + 1);
				}
				else if (button3->Text == "O") {
					win = true;
					MessageBox::Show(" Player O has Won ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label4->Text);
					label4->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			
			}
			//draww//===
			if (button1->Text != " " && button2->Text != " " && button3->Text != " " && button4->Text != " " && button5->Text != " " && button6->Text != " "
				&& button7->Text != " " && button8->Text != " " && button9->Text != " " ) {
				if (win == false) {
					MessageBox::Show(" Game Drawn ", " proj fin ", MessageBoxButtons::OK, MessageBoxIcon::Information);
					add = int::Parse(label8->Text);
					label8->Text = Convert::ToString(add + 1);
				}
				Enable_f();
			}
			//total
			total = int::Parse(label8->Text) + int::Parse(label4->Text)+ int::Parse( label3->Text);
			label9->Text = Convert::ToString(total);
			
			

			

		}
		
		//===========================//

private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button9->Text = "X";
		chck = true;
	}
	else {
		button9->Text = "O";
		chck = false;
	}
	score_board();
	button9->Enabled = false;

}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button1->Text = "X";
		chck = true;
	}
	else{
		button1->Text = "O";
		chck = false;
	}
	score_board();
	button1->Enabled = false;

}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button5->Text = "X";
		chck = true;
	}
	else {
		button5->Text = "O";
		chck = false;
	}
	score_board();
	button5->Enabled = false;

}

private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button2->Text = "X";
		chck = true;
	}
	else {
		button2->Text = "O";
		chck = false;
	}
	score_board();
	button2->Enabled = false;

}

 private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
 }
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button3->Text = "X";
		chck = true;
	}
	else {
		button3->Text = "O";
		chck = false;
	}
	score_board();
	button3->Enabled = false;
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button4->Text = "X";
		chck = true;
	}
	else {
		button4->Text = "O";
		chck = false;
	}
	score_board();
	button4->Enabled = false;
}
private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button6->Text = "X";
		chck = true;
	}
	else {
		button6->Text = "O";
		chck = false;
	}
	score_board();
	button6->Enabled = false;
}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button7->Text = "X";
		chck = true;
	}
	else {
		button7->Text = "O";
		chck = false;
	}
	score_board();
	button7->Enabled = false;
}
private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	if (chck == false) {
		button8->Text = "X";
		chck = true;
	}
	else {
		button8->Text = "O";
		chck = false;
	}
	score_board();
	button8->Enabled = false;
}
private: System::Void btnres_Click(System::Object^ sender, System::EventArgs^ e) {
	button1->Enabled = true;
	button2->Enabled = true;
	button3->Enabled = true;
	button4->Enabled = true;
	button5->Enabled = true;
	button6->Enabled = true;
	button7->Enabled = true;
	button8->Enabled = true;
	button9->Enabled = true;
	win = false;

	button1->Text = " ";
	button2->Text = " ";
	button3->Text = " ";
	button4->Text = " ";
	button5->Text = " ";
	button6->Text = " ";
	button7->Text = " ";
	button8->Text = " ";
	button9->Text = " ";
	
	btnNew->Enabled = true;

	button1->BackColor = System::Drawing::Color::White;
	button2->BackColor = System::Drawing::Color::White;
	button3->BackColor = System::Drawing::Color::White;
	button4->BackColor = System::Drawing::Color::White;
	button5->BackColor = System::Drawing::Color::White;
	button6->BackColor = System::Drawing::Color::White;
	button7->BackColor = System::Drawing::Color::White;
	button8->BackColor = System::Drawing::Color::White;
	button9->BackColor = System::Drawing::Color::White;

}
private: System::Void btnNew_Click(System::Object^ sender, System::EventArgs^ e) {
	button1->Enabled = true;
	button2->Enabled = true;
	button3->Enabled = true;
	button4->Enabled = true;
	button5->Enabled = true;
	button6->Enabled = true;
	button7->Enabled = true;
	button8->Enabled = true;
	button9->Enabled = true;
	win = false;

	button1->Text = " ";
	button2->Text = " ";
	button3->Text = " ";
	button4->Text = " ";
	button5->Text = " ";
	button6->Text = " ";
	button7->Text = " ";
	button8->Text = " ";
	button9->Text = " ";

	label3->Text = "0";
	label4->Text = "0";
	label8->Text = "0";
	label9->Text = "0";


	button1->BackColor = System::Drawing::Color::White;
	button2->BackColor = System::Drawing::Color::White;
	button3->BackColor = System::Drawing::Color::White;
	button4->BackColor = System::Drawing::Color::White;
	button5->BackColor = System::Drawing::Color::White;
	button6->BackColor = System::Drawing::Color::White;
	button7->BackColor = System::Drawing::Color::White;
	button8->BackColor = System::Drawing::Color::White;
	button9->BackColor = System::Drawing::Color::White;

}
	
private: System::Void panel2_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}
};
}
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;